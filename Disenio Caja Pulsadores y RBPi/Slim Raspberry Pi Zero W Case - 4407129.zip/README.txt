Slim Raspberry Pi Zero W Case by tvarok on Thingiverse: https://www.thingiverse.com/thing:4407129

Summary:
Slim Raspberry Pi Zero W case, with / without screws, no pin header.I recommend using the screws bottom version because, even though the 3d printed one works, due to being a very tight fit, it will break when taking apart the case to remove the pi.See pictures for more details!